//
//  ReservedRoomVariables.h
//  SFS2X
//
//  Original development by Infosfer Game Technologies Ltd. | http://www.infosfer.com.
//
//  Maintained and developed by A51 Integrated.
//  Copyright 2012 A51 Integrated | http://a51integrated.com. All rights reserved.
//


#import "Common.h"

EXTERN NSString * const ReservedRoomVariables_RV_GAME_STARTED;

@interface ReservedRoomVariables : NSObject { 
}

@end
