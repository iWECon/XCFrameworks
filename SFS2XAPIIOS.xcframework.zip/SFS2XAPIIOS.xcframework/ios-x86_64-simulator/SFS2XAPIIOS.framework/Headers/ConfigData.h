//
//  ConfigData.h
//  SFS2X
//
//  Original development by Infosfer Game Technologies Ltd. | http://www.infosfer.com.
//
//  Maintained and developed by A51 Integrated.
//  Copyright 2012 A51 Integrated | http://a51integrated.com. All rights reserved.
//

/**
 * Stores the client configuration data loaded from an external XML file.
 * @see [SmartFox2Client connectWithConfig:]
 */
@interface ConfigData : NSObject

@property NSString *host;
@property NSInteger port;
@property NSString *udpHost;
@property NSInteger udpPort;
@property NSString *zone;
@property BOOL debug;
@property NSInteger httpPort;
@property NSInteger httpsPort;
@property BOOL useBlueBox;
@property NSTimeInterval blueBoxPollingRate;

@end
