//
//  NSString+Encode.h
//  SFS2X
//
//  Created by Wayne Helman on 2012-10-17.
//  Copyright (c) 2012 A51 Integrated | http://a51integrated.com. All rights reserved.
//

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end
