//
//  ChangeRoomCapacityRequest.h
//  SFS2X
//
//  Original development by Infosfer Game Technologies Ltd. | http://www.infosfer.com.
//
//  Maintained and developed by A51 Integrated.
//  Copyright 2012 A51 Integrated | http://a51integrated.com. All rights reserved.
//

#import "BaseRequest.h"
#import "Room.h"

EXTERN NSString * const ChangeRoomCapacityRequest_KEY_ROOM;
EXTERN NSString * const ChangeRoomCapacityRequest_KEY_USER_SIZE;
EXTERN NSString * const ChangeRoomCapacityRequest_KEY_SPEC_SIZE;

/** Changes the capacity of a Room (maxUsers and maxSpectators) at runtime.
 
 This request might fail if the User sending the requestis not the owner of the Room. Moderators and Administrator can override this  constraint.
 
 If the Room was configured so that resizing is not allowed (see the <em>RoomSettings.permissions</em> parameter), the request is ignored and no error is fired.
 
 It is possible to "shrink" the Room capacity so that maxUsers < userCount. In this case nothing will happen to the "extra" users.
 As soon as clients will leave the Room the userCount will get down to the new maxUsers value.
 
 Also note that some restrictions are applied to the passed values (i.e. a client can't set the max users to more than 200, or the max spectators to more than 32).
 */ 
@interface ChangeRoomCapacityRequest : BaseRequest {
	
	id<Room> _room;
	NSInteger _newMaxUsers;
	NSInteger _newMaxSpect;

}


/**
 @param room the Room to resize
 @param newMaxUsers the new maxUsers value
 @param newMaxSpect the new maxSpect value 
 
 
 @see [ISFSEvents onRoomCapacityChange:]
 @see [ISFSEvents onRoomCapacityChangeError:]
 @see ChangeRoomNameRequest
 @see ChangeRoomPasswordStateRequest
 
 */
+(id)requestWithRoom:(id<Room>)room newMaxUsers:(NSInteger)newMaxUsers newMaxSpect:(NSInteger)newMaxSpect;

@end
