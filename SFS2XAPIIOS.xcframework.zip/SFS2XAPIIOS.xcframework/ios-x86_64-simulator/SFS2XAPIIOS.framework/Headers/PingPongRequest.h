//
//  PingPongRequest.h
//  SFS2X
//
//  Created by Lapo on 25/02/14.
//

#import "BaseRequest.h"

@interface PingPongRequest : BaseRequest

+(id)request;

@end
