//
//  SmartFox2XClient+ConnectingStatus.h
//  BaseIM
//
//  Created by iWw on 11/4/20.
//

//#import <SFS2XAPIIOS/SFS2XAPIIOS.h>
#import "SmartFox2XClient.h"

NS_ASSUME_NONNULL_BEGIN

@interface SmartFox2XClient (ConnectingStatus)

@property (nonatomic, assign) BOOL clientConnecting;

- (void)resetClient;

@end

NS_ASSUME_NONNULL_END
