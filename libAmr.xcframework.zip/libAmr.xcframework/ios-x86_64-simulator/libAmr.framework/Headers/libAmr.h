//
//  libAmr.h
//  libAmr
//
//  Created by iWw on 11/16/20.
//

#import <Foundation/Foundation.h>

//! Project version number for libAmr.
FOUNDATION_EXPORT double libAmrVersionNumber;

//! Project version string for libAmr.
FOUNDATION_EXPORT const unsigned char libAmrVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libAmr/PublicHeader.h>

#import "header-libAmr.h"
#import "VoiceConverter.h"
