//
//  NSStream+QNetworkAdditions.h
//  SFS2X
//
//  Created by Lapo on 08/10/18.
//  Copyright © 2018 A51 Integrated | http://a51integrated.com. All rights reserved.
//

#ifndef NSStream_QNetworkAdditions_h
#define NSStream_QNetworkAdditions_h

@interface NSStream (QNetworkAdditions)

+ (void)qNetworkAdditions_getStreamsToHostNamed:(NSString *)hostName
                                           port:(NSInteger)port
                                    inputStream:(out NSInputStream **)inputStreamPtr
                                   outputStream:(out NSOutputStream **)outputStreamPtr;

@end


#endif /* NSStream_QNetworkAdditions_h */
