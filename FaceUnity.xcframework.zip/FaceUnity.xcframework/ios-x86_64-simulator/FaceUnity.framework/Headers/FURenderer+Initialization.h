//
//  FURenderer+Initialization.h
//  FaceUnity
//
//  Created by iWw on 11/6/20.
//

#import <Foundation/Foundation.h>
#import "FURenderer.h"

@interface FURenderer (Initialization)

+ (void)prepareFaceUnity;

+ (void)loadAIFaceProcessor;

+ (void)destroyAIFaceProcessor;

+ (void)safeCameraChanged;

@end
