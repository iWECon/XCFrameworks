//
//  ConnectionMode.h
//  SFS2X
//
//  Created by Wayne Helman on 2012-08-13.
//  Copyright (c) 2012 A51 Integrated | http://a51integrated.com. All rights reserved.
//

#import "Common.h"

EXTERN NSString * const ConnectionMode_SOCKET;
EXTERN NSString * const ConnectionMode_HTTP;

@interface ConnectionMode : NSObject



@end
