//
//  ChangeRoomNameRequest.h
//  SFS2X
//
//  Original development by Infosfer Game Technologies Ltd. | http://www.infosfer.com.
//
//  Maintained and developed by A51 Integrated.
//  Copyright 2012 A51 Integrated | http://a51integrated.com. All rights reserved.
//


#import "BaseRequest.h"
#import "Room.h"

EXTERN NSString * const ChangeRoomNameRequest_KEY_ROOM;
EXTERN NSString * const ChangeRoomNameRequest_KEY_NAME;

/** Changes the name of a Room at runtime.
 
 This request will fail if the User sending the request is not the creator of the Room.
 
 Moderators and Administrator can override this last constraint.
 
 If the Room was configured so that renaming is not allowed (see the <em>RoomSettings.permissions</em> parameter), the request is ignored and no error is fired.
 */ 
@interface ChangeRoomNameRequest : BaseRequest {
		
	id<Room> _room;
	NSString *_newName;
}

/**
 @param room the Room to rename
 @param newName	the new Room name (no duplicates are allowed)
 
 @see [ISFSEvents onRoomNameChange:]
 @see [ISFSEvents onRoomNameChangeError:]
 
 @see ChangeRoomCapacityRequest
 @see ChangeRoomPasswordStateRequest
 
 */
+(id)requestWithRoom:(id<Room>)room newName:(NSString *)newName;

@end
